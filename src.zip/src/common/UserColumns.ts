export const UserColumns = {
    id: true,
    name: true,
    username: true,
    email: true,
}